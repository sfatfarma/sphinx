angular.module('sphsettingsApp', ['ngSanitize'])
.controller('sphsettingsController', function($scope) {
    $scope.settings = sphinx_admin_json;
    $scope.chrome_ver = [];
    // Included version numbers which are currently stable (at latest plugin update)
    // and 5 future versions at most
    var initChrome = function() {
      var i;
      for (i = 1;i <= 59; i++) {
        $scope.chrome_ver.push(i);
      }
    }
    initChrome();
    $scope.firefox_ver = [];
    var initFirefox = function() {
      var i;
      for (i = 1;i <= 54; i++) {
        $scope.firefox_ver.push(i);
      }
    }
    initFirefox();
    $scope.ie_ver = [];
    var initIe = function() {
      var i;
      for (i = 1;i <= 11; i++) {
        $scope.ie_ver.push(i);
      }
    }
    initIe();
    $scope.opera_ver = [];
    var initOpera = function() {
      var i;
      for (i = 1;i <= 46; i++) {
        $scope.opera_ver.push(i);
      }
    }
    initOpera();
    $scope.safari_ver = [];
    var initSafari = function() {
      var i;
      for (i = 1;i <= 12; i++) {
        $scope.safari_ver.push(i);
      }
    }
    initSafari();
    $scope.edge_ver = [];
    var initEdge = function() {
      var i;
      for (i = 1;i <= 43; i++) {
        $scope.edge_ver.push(i);
      }
    }
    initEdge();
});