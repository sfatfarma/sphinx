angular.module('sphsettingsApp', ['ngSanitize'])
.controller('sphsettingsController', function($scope) {
    $scope.settings = sphinx_admin_json;
    // Included version numbers which are currently stable (at latest plugin update)
    // and 5 future versions at most (for the often updated browsers)
    $scope.edge_ver = [];
    var initEdge = function() {
      var i;
      for (i = 1;i <= parseInt(settings.edge)+5; i++) {
        $scope.edge_ver.push(i);
      }
    }
    initEdge();
    $scope.chrome_ver = [];
    var initChrome = function() {
      var i;
      for (i = 1;i <= parseInt(settings.chrome)+5; i++) {
        $scope.chrome_ver.push(i);
      }
    }
    initChrome();
    $scope.firefox_ver = [];
    var initFirefox = function() {
      var i;
      for (i = 1;i <= parseInt(settings.firefox)+5; i++) {
        $scope.firefox_ver.push(i);
      }
    }
    initFirefox();
    $scope.ie_ver = [];
    var initIe = function() {
      var i;
      for (i = 1;i <= parseInt(settings.ie); i++) {
        $scope.ie_ver.push(i);
      }
    }
    initIe();
    $scope.opera_ver = [];
    var initOpera = function() {
      var i;
      for (i = 1;i <= parseInt(settings.opera)+5; i++) {
        $scope.opera_ver.push(i);
      }
    }
    initOpera();
    $scope.safari_ver = [];
    var initSafari = function() {
      var i;
      for (i = 1;i <= parseInt(settings.safari)+1; i++) {
        $scope.safari_ver.push(i);
      }
    }
    initSafari();
});