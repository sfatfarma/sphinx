<?php

function sphinx_get_browser_version($user_agent, $continue_mobile) {
        $user_agent = strtolower($user_agent);
        $browser = '';
        $version = '';
        preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
        preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
        preg_match( '/googlebot|adsbot|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/', $user_agent, $matches3);//bot
        $obj = new SphinxBrowserDetection();
        $version = $obj->sphinx_detect()->sphinx_getVersion();
        $browser = $obj->sphinx_detect()->sphinx_getBrowser();
        
        if((!$matches && !$matches2 && !$matches3) || $continue_mobile == 'on')
        {
	    	if(stripos($browser, 'explorer') !== false) {
	    		$browser = 'ie';
	    	} 
	    	elseif(stripos($browser, 'chrome') !== false) {
                if( stripos($user_agent,'edge/') !== false ) 
                {
                    $aresult = explode('/', stristr($user_agent, 'edge'));
                    if (isset($aresult[1])) 
                    {
                        $aversion = explode(' ', $aresult[1]);
                        $version = $aversion[0];
                        $browser = 'edge';
                    }
                    else
                    {
                        $browser = 'chrome';
                    }
                }
                else
                {
                    $browser = 'chrome';
                }
	    	}
            elseif(stripos($browser, 'edge') !== false) {
				$browser = 'edge';
	    	} 
	    	elseif(stripos($browser, 'safari') !== false) {
				$browser = 'safari';
			} 
			elseif(stripos($browser, 'opera') !== false) {
				$browser = 'opera';
			} 
			elseif(stripos($browser, 'firefox') !== false) {
				$browser = 'firefox';
			}
        }
        if($version == "")
        {
            preg_match('/MSIE (.*?);/', $_SERVER['HTTP_USER_AGENT'], $matches);
            if(count($matches)<2){ 
              preg_match('/trident\/\d{1,2}.\d{1,2}; rv:([0-9]*)/', strtolower($_SERVER['HTTP_USER_AGENT']), $matches);
            }
            if (count($matches)>1){
              $version = $matches[1];    
            }
        }
        if($version == "")
        {
            $agent = $_SERVER['HTTP_USER_AGENT'];
            if(stripos($agent,'edge/') !== false ) 
            {
                $aresult = explode('/', stristr($agent, 'Edge'));
                if (isset($aresult[1])) 
                {
                    $aversion = explode(' ', $aresult[1]);
                    $version = $aversion[0];
                    $browser = 'edge';
                }
                
            }
        }
        return array(
            'name' => $browser,
            'version' => $version
        );
    }

function sphinx_is_mobile($user_agent) {
    $user_agent = strtolower($user_agent);
    preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
    preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
    if($matches || $matches2) {
		//mobile
        return true;
    }
    else
    {
        //desktop or bot
        return false;
    }
}
    
function sphinx_admin_settings()
{
    global $chrome_curr_ver, $firefox_curr_ver, $ie_curr_ver, $opera_curr_ver, $safari_curr_ver, $edge_curr_ver;
?>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('sphinx_option_group');
    do_settings_sections('sphinx_option_group');
    $sphinx_Main_Settings = get_option('sphinx_Main_Settings', false);
    if (isset($sphinx_Main_Settings['sphinx_enabled'])) {
        $sphinx_enabled = $sphinx_Main_Settings['sphinx_enabled'];
    } else {
        $sphinx_enabled = 'off';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_chrome'])) {
        $sfinx_ver_chrome = $sphinx_Main_Settings['sfinx_ver_chrome'];
    } else {
        $sfinx_ver_chrome = '32';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_firefox'])) {
        $sfinx_ver_firefox = $sphinx_Main_Settings['sfinx_ver_firefox'];
    } else {
        $sfinx_ver_firefox = '12';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_ie'])) {
        $sfinx_ver_ie = $sphinx_Main_Settings['sfinx_ver_ie'];
    } else {
        $sfinx_ver_ie = '8';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_opera'])) {
        $sfinx_ver_opera = $sphinx_Main_Settings['sfinx_ver_opera'];
    } else {
        $sfinx_ver_opera = '10';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_safari'])) {
        $sfinx_ver_safari = $sphinx_Main_Settings['sfinx_ver_safari'];
    } else {
        $sfinx_ver_safari = '8';
    }
    if (isset($sphinx_Main_Settings['sfinx_mobile_support'])) {
        $sfinx_mobile_support = $sphinx_Main_Settings['sfinx_mobile_support'];
    } else {
        $sfinx_mobile_support = 'YES';
    }
    if (isset($sphinx_Main_Settings['sfinx_ver_edge'])) {
        $sfinx_ver_edge = $sphinx_Main_Settings['sfinx_ver_edge'];
    } else {
        $sfinx_ver_edge = '8';
    }
    if (isset($sphinx_Main_Settings['sfinx_mobile_title'])) {
        $sfinx_mobile_title = $sphinx_Main_Settings['sfinx_mobile_title'];
    } else {
        $sfinx_mobile_title = 'Not supported on mobile devices!';
    }
    if (isset($sphinx_Main_Settings['sfinx_mobile_message'])) {
        $sfinx_mobile_message = $sphinx_Main_Settings['sfinx_mobile_message'];
    } else {
        $sfinx_mobile_message = 'Please load this page only on desktop computers!';
    }
    if (isset($sphinx_Main_Settings['sfinx_mobile_panel_message'])) {
        $sfinx_mobile_panel_message = $sphinx_Main_Settings['sfinx_mobile_panel_message'];
    } else {
        $sfinx_mobile_panel_message = 'Please load this page only on desktop computers!';
    }
    if (isset($sphinx_Main_Settings['sfinx_message_title'])) {
        $sfinx_message_title = $sphinx_Main_Settings['sfinx_message_title'];
    } else {
        $sfinx_message_title = 'Your browser is not supported!';
    }
    if (isset($sphinx_Main_Settings['sfinx_message'])) {
        $sfinx_message = $sphinx_Main_Settings['sfinx_message'];
    } else {
        $sfinx_message = 'Please download the latest browser and try again!';
    }
    if (isset($sphinx_Main_Settings['sfinx_style'])) {
        $sfinx_style = $sphinx_Main_Settings['sfinx_style'];
    } else {
        $sfinx_style = 'sfinx_popup';
    }
    $sfinx_links = $sphinx_Main_Settings['sfinx_links'];
    $sfinx_warn = $sphinx_Main_Settings['sfinx_warn'];
    $sfinx_click_close = $sphinx_Main_Settings['sfinx_click_close'];
    $sfinx_popup_once = $sphinx_Main_Settings['sfinx_popup_once'];
    $sfinx_check_mobile = $sphinx_Main_Settings['sfinx_check_mobile'];
    $sfinx_panel_sticks = $sphinx_Main_Settings['sfinx_panel_sticks'];
    if (isset($sphinx_Main_Settings['sfinx_close_popup'])) {
        $sfinx_close_popup = $sphinx_Main_Settings['sfinx_close_popup'];
    } else {
        $sfinx_close_popup = 'Continue to this website anyway';
    }
    if (isset($sphinx_Main_Settings['sfinx_panel_message'])) {
        $sfinx_panel_message = $sphinx_Main_Settings['sfinx_panel_message'];
    } else {
        $sfinx_panel_message = 'This site does not support your browser! Please update it!';
    }
    if (isset($sphinx_Main_Settings['sfinx_panel_close_message'])) {
        $sfinx_panel_close_message = $sphinx_Main_Settings['sfinx_panel_close_message'];
    } else {
        $sfinx_panel_close_message = 'Close';
    }
    if (isset($sphinx_Main_Settings['sfinx_popup_background'])) {
        $sfinx_popup_background = $sphinx_Main_Settings['sfinx_popup_background'];
    } else {
        $sfinx_popup_background = '#ffffff';
    }
    if (isset($sphinx_Main_Settings['sfinx_panel_background'])) {
        $sfinx_panel_background = $sphinx_Main_Settings['sfinx_panel_background'];
    } else {
        $sfinx_panel_background = '#aaaaaa';
    }
    if (isset($sphinx_Main_Settings['sfinx_popup_text_col'])) {
        $sfinx_popup_text_col = $sphinx_Main_Settings['sfinx_popup_text_col'];
    } else {
        $sfinx_popup_text_col = '#000000';
    }
    if (isset($sphinx_Main_Settings['sfinx_panel_text_col'])) {
        $sfinx_panel_text_col = $sphinx_Main_Settings['sfinx_panel_text_col'];
    } else {
        $sfinx_panel_text_col = '#000000';
    }
    if (isset($sphinx_Main_Settings['sfinx_popup_links_col'])) {
        $sfinx_popup_links_col = $sphinx_Main_Settings['sfinx_popup_links_col'];
    } else {
        $sfinx_popup_links_col = '#0000ff';
    }
    if (isset($sphinx_Main_Settings['sfinx_panel_links_col'])) {
        $sfinx_panel_links_col = $sphinx_Main_Settings['sfinx_panel_links_col'];
    } else {
        $sfinx_panel_links_col = '#0000ff';
    }
    if (isset($sphinx_Main_Settings['sfinx_mobile_panel_close'])) {
        $sfinx_mobile_panel_close = $sphinx_Main_Settings['sfinx_mobile_panel_close'];
    } else {
        $sfinx_mobile_panel_close = 'Close';
    }
?>
<script>
                var sphinx_admin_json = {
                    sphinx_enabled: '<?php
    echo $sphinx_enabled;
?>',
                    sfinx_ver_chrome: '<?php
    echo $sfinx_ver_chrome;
?>',
                    sfinx_ver_firefox: '<?php
    echo $sfinx_ver_firefox;
?>',
                    sfinx_ver_ie: '<?php
    echo $sfinx_ver_ie;
?>',
                    sfinx_ver_opera: '<?php
    echo $sfinx_ver_opera;
?>',
                    sfinx_ver_safari: '<?php
    echo $sfinx_ver_safari;
?>',
                    sfinx_mobile_support: '<?php
    echo $sfinx_mobile_support;
?>',
                    sfinx_ver_edge: '<?php
    echo $sfinx_ver_edge;
?>',
                    sfinx_mobile_title: '<?php
    echo $sfinx_mobile_title;
?>',
                    sfinx_mobile_message: '<?php
    echo $sfinx_mobile_message;
?>',
                    sfinx_mobile_panel_message: '<?php
    echo $sfinx_mobile_panel_message;
?>',
                    sfinx_message_title: '<?php
    echo $sfinx_message_title;
?>',
                    sfinx_message: '<?php
    echo $sfinx_message;
?>',
                    sfinx_links: '<?php
    echo $sfinx_links;
?>',
                    sfinx_warn: '<?php
    echo $sfinx_warn;
?>',
                    sfinx_click_close: '<?php
    echo $sfinx_click_close;
?>',
                    sfinx_close_popup: '<?php
    echo $sfinx_close_popup;
?>',
                    sfinx_popup_once: '<?php
    echo $sfinx_popup_once;
?>',
                    sfinx_check_mobile: '<?php
    echo $sfinx_check_mobile;
?>',
                    sfinx_style: '<?php
    echo $sfinx_style;
?>',
                    sfinx_panel_message: '<?php
    echo $sfinx_panel_message;
?>',
                    sfinx_panel_close_message: '<?php
    echo $sfinx_panel_close_message;
?>',
                    sfinx_panel_sticks: '<?php
    echo $sfinx_panel_sticks;
?>',
                    sfinx_popup_background: '<?php
    echo $sfinx_popup_background;
?>',
                    sfinx_panel_background: '<?php
    echo $sfinx_panel_background;
?>',
                    sfinx_popup_text_col: '<?php
    echo $sfinx_popup_text_col;
?>',
                    sfinx_panel_text_col: '<?php
    echo $sfinx_panel_text_col;
?>',
                    sfinx_popup_links_col: '<?php
    echo $sfinx_popup_links_col;
?>',
                    sfinx_panel_links_col: '<?php
    echo $sfinx_panel_links_col;
?>',
                    sfinx_mobile_panel_close: '<?php
    echo $sfinx_mobile_panel_close;
?>'

}
            </script>
            <script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('.sfinx_warn').is(":checked"))
        {            
            jQuery(".hideBot").show();
        }
        else
        {
            jQuery(".hideBot").hide();
        }
        if(jQuery("#mobail option:selected").text().trim() === 'NO') 
        {            
            jQuery(".mobHide").show();
            jQuery(".showBot").hide();
        }
        else
        {
            jQuery(".mobHide").hide();
            jQuery(".showBot").show();
        }
    }
    window.onload = function() {
        var ex1 = document.getElementById('radio_gs_yes');
        var ex2 = document.getElementById('radio_gs_exp');
        ex1.onclick = handlerYES;
        ex2.onclick = handlerEXP;
        if(jQuery('input[name="sphinx_Main_Settings[sfinx_style]"]:checked').val() === 'sfinx_panel')
        {
            jQuery(".popupStyle").hide();
            jQuery(".panelStyle").show();
        }
        else
        {
            jQuery(".popupStyle").show();
            jQuery(".panelStyle").hide();
        }
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('.sfinx_warn').is(":checked"))
        {            
            jQuery(".hideBot").show();
        }
        else
        {
            jQuery(".hideBot").hide();
        }
        if(jQuery("#mobail option:selected").text().trim() === 'NO') 
        {            
            jQuery(".mobHide").show();
            jQuery(".showBot").hide();
        }
        else
        {
            jQuery(".mobHide").hide();
            jQuery(".showBot").show();
        }
    }
    function handlerYES() 
    {
        jQuery(".popupStyle").show();
        jQuery(".panelStyle").hide();
    }

    function handlerEXP() 
    {  
        jQuery(".popupStyle").hide();
        jQuery(".panelStyle").show();
    }
    </script>
<div ng-app="sphsettingsApp" ng-controller="sphsettingsController" ng-cloak ng-init="initialized()">
<div>
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Sphinx Main Switch:</b>&nbsp;&nbsp;&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Sphinx Plugin.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="sphinx_enabled" name="sphinx_Main_Settings[sphinx_enabled]" onChange="mainChanged()" <?php
    if ($sphinx_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="sphinx_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table>
                    <div>
                    <tr><td>
                    <b>The Minimum Version of Google Chrome that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_chrome]" ng-model="settings.sfinx_ver_chrome" style="width:200px;">
                        <option value="ALL">
                            All Chrome versions
                        </option>
                        <option value="NO">
                            No Chrome versions
                        </option>
                        <option value="<?php echo $chrome_curr_ver-2;?>">
                            Newer than 3 months
                        </option>
                        <option value="<?php echo $chrome_curr_ver-4;?>">
                            Newer than 6 months
                        </option>
                        <option value="<?php echo $chrome_curr_ver-6;?>">
                            Newer than 9 months
                        </option>
                        <option value="<?php echo $chrome_curr_ver-8;?>">
                            Newer than 12 months
                        </option>
                        <option  ng-repeat="date in chrome_ver" value="{{date}}">
                            {{date}}
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Google Chrome your website visitors can use, without being notified by this plugin. You can also select 'Newer than X months', to filter browsers by their release date.";
                ?>
                        </div>
                    </div>
                    </td></tr>
                    
        </div>
        <div>
                    <tr><td>
                    <b>The Minimum Version of Firefox that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_firefox]" ng-model="settings.sfinx_ver_firefox" style="width:200px;">
                        <option value="ALL">
                            All Firefox versions
                        </option>
                        <option value="NO">
                            No Firefox versions
                        </option>
                        <option value="<?php echo $firefox_curr_ver-1;?>">
                            Newer than 3 months
                        </option>
                        <option value="<?php echo $firefox_curr_ver-3;?>">
                            Newer than 6 months
                        </option>
                        <option value="<?php echo $firefox_curr_ver-4;?>">
                            Newer than 9 months
                        </option>
                        <option value="<?php echo $firefox_curr_ver-6;?>">
                            Newer than 12 months
                        </option>
                        <option  ng-repeat="date in firefox_ver" value="{{date}}">
                            {{date}}
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Firefox your website visitors can use, without being notified by this plugin. You can also select 'Newer than X months', to filter browsers by their release date.";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The Minimum Version of Internet Explorer that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_ie]" ng-model="settings.sfinx_ver_ie" style="width:200px;">
                        <option value="ALL">
                            All IE versions
                        </option>
                        <option value="NO">
                            No IE versions
                        </option>
                        <option  ng-repeat="date in ie_ver" value="{{date}}">
                            {{date}}
                        </option> 
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Internet Explorer your website visitors can use, without being notified by this plugin. Internet Explorer is a discontinued browser, it's latest version is 11.";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The Minimum Version of Opera that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_opera]" ng-model="settings.sfinx_ver_opera" style="width:200px;">
                        <option value="ALL">
                            All Opera versions
                        </option>
                        <option value="NO">
                            No Opera versions
                        </option>
                        <option value="<?php echo $opera_curr_ver-2;?>">
                            Newer than 3 months
                        </option>
                        <option value="<?php echo $opera_curr_ver-5;?>">
                            Newer than 6 months
                        </option>
                        <option value="<?php echo $opera_curr_ver-7;?>">
                            Newer than 9 months
                        </option>
                        <option value="<?php echo $opera_curr_ver-10;?>">
                            Newer than 12 months
                        </option>
                        <option  ng-repeat="date in opera_ver" value="{{date}}">
                            {{date}}
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Opera your website visitors can use, without being notified by this plugin. You can also select 'Newer than X months', to filter browsers by their release date.";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The Minimum Version of Safari that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_safari]" ng-model="settings.sfinx_ver_safari" style="width:200px;">
                        <option value="ALL">
                            All Safari versions
                        </option>
                        <option value="NO">
                            No Safari versions
                        </option>
                        <option  ng-repeat="date in safari_ver" value="{{date}}">
                            {{date}}
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Safari your website visitors can use, without being notified by this plugin. Note that on Windows, Safari is a discontinued browser, with it's latest version being 5, released in 2009. On MacOS, Safari is being updated regularly.";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The Minimum Version of Edge that your Website Supports:</b>
                    </td><td>
                    <select name="sphinx_Main_Settings[sfinx_ver_edge]" ng-model="settings.sfinx_ver_edge" style="width:200px;">
                        <option value="ALL">
                            All Edge versions
                        </option>
                        <option value="NO">
                            No Edge versions
                        </option>
                        <option  ng-repeat="edge in edge_ver" value="{{edge}}">
                            {{edge}}
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Here you can specify the minimum version of Microsoft Edge your website visitors can use, without being notified by this plugin. Note that this version refers to the version of EdgeHTML (the HTML parser build in Edge), not actually the Edge browser.";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Allow Mobile Device Browsers:</b>
                    </td><td>
                    <select id='mobail' class='mobail' name="sphinx_Main_Settings[sfinx_mobile_support]" ng-model="settings.sfinx_mobile_support" style="width:200px;" onchange="mainChanged()">
                        <option value="YES">
                            YES
                        </option>
                        <option value="NO">
                            NO
                        </option>
                    </select> 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Does your website offer mobile support? Do you want to allow visitors on your website to access it using mobile devices? I strongly recommend that you leave this on 'YES'!";
                ?>
                        </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="showBot">
                    <b>Check Browser Version on Mobile Devices:</b>
                    </div>
                    </td><td>
                    <div class="showBot">
                    <input type="checkbox" id="sfinx_check_mobile" name="sphinx_Main_Settings[sfinx_check_mobile]" <?php
    if ($sfinx_check_mobile == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want to check browser versions on mobile devices? Same rules apply as for desktop browsers.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <div class='mobHide'>
                    <b>Not Supported on Mobile Message Title:</b>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <div class='mobHide'>
                    <b>Not Supported on Mobile Close Text:</b>
                    </div>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <div class='mobHide'>
                    <textarea rows="1" cols="44" name="sphinx_Main_Settings[sfinx_mobile_title]" ng-model="settings.sfinx_mobile_title"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Title of the Message that will be shown on mobile devices, if you select to not support them.";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <div class='mobHide'>
                    <textarea rows="1" cols="44" name="sphinx_Main_Settings[sfinx_mobile_panel_close]" ng-model="settings.sfinx_mobile_panel_close"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Text of the link that will close the warning message in the upper panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="panelStyle">
                    <div class='mobHide'>
                    <b>Not Supported on Mobile Panel Message:</b>
                    </div>
                    </div>
                    <div class="popupStyle">
                    <div class='mobHide'>
                    <b>Not Supported on Mobile Message:</b>
                    </div>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <div class='mobHide'>
                    <textarea rows="4" cols="44" name="sphinx_Main_Settings[sfinx_mobile_message]" ng-model="settings.sfinx_mobile_message"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Message to be shown on mobile devices, if you select to not support them.";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <div class='mobHide'>
                    <textarea rows="4" cols="44" name="sphinx_Main_Settings[sfinx_mobile_panel_message]" ng-model="settings.sfinx_mobile_panel_message"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Message to be shown on mobile devices, in the upper panel, if you select to not support them.";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <tr><td><hr/></td><td><hr/></td></tr>
        <div>
                    <tr><td>
                    <div class="hideBot">
                    <b>Show Only Once per Visitor:</b>
                    </div>
                    </td><td>
                    <div class="hideBot">
                    <input type="checkbox" id="sfinx_popup_once" name="sphinx_Main_Settings[sfinx_popup_once]" <?php
    if ($sfinx_popup_once == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want to show the popup only once per visitor? (uses cookies - cookie expiration date set to 24 hours)";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
                    <tr><td>
                        <span class="gs-sub-heading"><b>User Notification Style:</b>&nbsp;&nbsp;&nbsp;</span>
                        </td><td>
                        <label><input type="radio" name="sphinx_Main_Settings[sfinx_style]" value="sfinx_popup"
                            id="radio_gs_yes" ng-model="settings.sfinx_style"> Popup Style</label>&nbsp; 
                        <label><input type="radio" name="sphinx_Main_Settings[sfinx_style]" value="sfinx_panel"
                            id="radio_gs_exp" ng-model="settings.sfinx_style"> Top Panel Style</label>&nbsp; 
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                        echo "How the message will be displayed to the user. You can choose between popup and top notification panel.";
                    ?>
                            </div>
                        </div>
                        </td></tr>
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td>
        <div class="popupStyle">
                    <i><b>Popup Settings:</b></i><br/><br/>
                    </div>
                    <div class="panelStyle">
                    <i><b>Panel Settings:</b></i><br/><br/>
                    </div>
                    </td><td></td></tr>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Message Title:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Message:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <textarea rows="2" cols="44" name="sphinx_Main_Settings[sfinx_message_title]" ng-model="settings.sfinx_message_title"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Title of the 'Browser Not Supported' message to be shown.";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <textarea rows="2" cols="44" name="sphinx_Main_Settings[sfinx_panel_message]" ng-model="settings.sfinx_panel_message"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The body of the 'Browser Not Supported' message to be shown in the upper panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Message:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Close Text:</b>
                    </td><td>
                    <div class="popupStyle">
                    <textarea rows="4" cols="44" name="sphinx_Main_Settings[sfinx_message]" ng-model="settings.sfinx_message"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The 'Browser Not Supported' message to be shown to the user.";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <textarea rows="4" cols="44" name="sphinx_Main_Settings[sfinx_panel_close_message]" ng-model="settings.sfinx_panel_close_message"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The text of the link that will close the upper panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Include Download Link to Supported Browsers:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Sticks to the Top of the Page:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <input type="checkbox" id="sfinx_links" name="sphinx_Main_Settings[sfinx_links]" <?php
    if ($sfinx_links == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want to include links (with images) to download the browsers you set as supported for your webpage?";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <input type="checkbox" id="sfinx_panel_sticks" name="sphinx_Main_Settings[sfinx_panel_sticks]" <?php
    if ($sfinx_panel_sticks == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want the panel to stick to the top of the page, or you would like users to be able to scroll down and hide the panel?";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Popup Background Color:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Background Color:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_popup_background]" ng-model="settings.sfinx_popup_background">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the backgound of your popup.";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_panel_background]" ng-model="settings.sfinx_panel_background">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the backgound of your panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Popup Text Color:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Text Color:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_popup_text_col]" ng-model="settings.sfinx_popup_text_col">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the text of your popup.";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_panel_text_col]" ng-model="settings.sfinx_panel_text_col">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the text of your panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Popup Closing Link Color:</b>
                    </div>
                    <div class="panelStyle">
                    <b>Panel Closing Link Color:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_popup_links_col]" ng-model="settings.sfinx_popup_links_col">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the links (including the closing link) of your popup.";
                ?>
                        </div>
                    </div>
                    </div>
                    <div class="panelStyle">
                    <input type="color" name="sphinx_Main_Settings[sfinx_panel_links_col]" ng-model="settings.sfinx_panel_links_col">
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The color of the links (including the closing link) of your panel.";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <b>Warn Users Only, Do Not Block the Website:</b>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <input type="checkbox" class="sfinx_warn" id="sfinx_warn" name="sphinx_Main_Settings[sfinx_warn]" onChange="mainChanged()" <?php
    if ($sfinx_warn == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want to block your visitors from visiting your website or only warn them (if you choose to block the website, it will be blanked out, the only thing visible will be the popup)?";
                ?>
                        </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <div class="hideBot">
                    <b>Popup Close Text:</b>
                    </div>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <div class="hideBot">
                    <textarea rows="1" cols="44" name="sphinx_Main_Settings[sfinx_close_popup]" ng-model="settings.sfinx_close_popup"></textarea>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "The text of the link that will close the popup?";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="popupStyle">
                    <div class="hideBot">
                    <b>Clicking Outside Will Close the Popup:</b>
                    </div>
                    </div>
                    </td><td>
                    <div class="popupStyle">
                    <div class="hideBot">
                    <input type="checkbox" id="sfinx_click_close" name="sphinx_Main_Settings[sfinx_click_close]" <?php
    if ($sfinx_click_close == 'on')
        echo ' checked ';
?>>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
                    echo "Do you want to close the popup by clicking outside it (in the gray area)?";
                ?>
                        </div>
                    </div>
                    </div>
                    </div>
                    </td></tr>
        </div>
        </table>
        <hr/>
        <b>INFO: You can add the [sphinx_browser_info] shortcode to your website to display information about the user's browser, just like below:</b><br/><br/>
        <?php
        $obj = new SphinxBrowserDetection();
        echo $obj->sphinx_detect()->sphinx_getInfo();
        ?>
        </div>
        </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div><?php
}
?>