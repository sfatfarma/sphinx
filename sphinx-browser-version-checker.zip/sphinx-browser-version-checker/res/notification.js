(function($) {
  "use strict" 
	$(document).ready(function() {
		var $doc = $(document)
          , $body = $('body')
          , $modal;
        if(settings.panel === 'no')
        {
            if(settings.use_cookies === 'on' && settings.warn === 'on')
            {
                var sphinx_show = $.cookie("sphinx_show");
                if (sphinx_show == null) {
                    $.cookie("sphinx_show", 1, { expires : 1 });
                }
                else
                {
                    return;
                }
            }
            $modal = '<script type="text/javascript">function sphinx_hide_overlay(){jQuery(".sphinx-overlay").hide();}function cancelBubble(e) {var evt = e ? e:window.event;if (evt.stopPropagation)    evt.stopPropagation();if (evt.cancelBubble!=null) evt.cancelBubble = true;}</script>';
            if(settings.warn === 'on' && settings.click_outside === 'on')
            {
                $modal += '<div class="sphinx-overlay" id="sphinx-overlay" style="background: rgba(0,0,0,0.8)" onclick="sphinx_hide_overlay()">';
            }
            else
            {
                $modal += '<div class="sphinx-overlay" id="sphinx-overlay" style="background: rgba(0,0,0,0.8)">';
            }
            
            $modal += '<div class="sphinx-wrapper" onclick="cancelBubble(event)" style="background: '+settings.bkgrnd+'">';
            $modal += '<h3 style="color: '+settings.text+'">' + settings.msg.title + '</h3>';
            $modal += '<p style="color: '+settings.text+'">' + settings.msg.content + '</p>';
            $modal += '<div class="sphinx-browser-container clearfix">';
            
            $.each(settings.browser, function(key, obj) {
                $modal += '<div class="sphinx-browser">';
                $modal += '<a class="sphinx-browser-icon" href="' + obj.url + '" target="_blank" style="color: '+settings.links+'"><img src="' + obj.icon + '"/></a>';
                $modal += '<a href="' + obj.url + '" target="_blank" style="color: '+settings.links+'">' + obj.name + '</a>';
                $modal += '<p style="color: '+settings.text+'">' + obj.version + '</p>';
                $modal += '</div>';    
            });
            if(settings.warn === 'on') 
            {
                $modal += '<div><a href="#" onclick="sphinx_hide_overlay();" style="color: '+settings.links+'">'+settings.close_message+'</a></div>';
            }
            $modal += '</div>';
            $modal += '</div>';
            $modal += '</div>';   
            if(settings.warn === 'on')
            {
                $body.append($modal);
            }
            else
            {
                $body.replaceWith($modal);
            }
        }
        else
        {
            if(settings.use_cookies === 'on')
            {
                var sphinx_show = $.cookie("sphinx_show");
                if (sphinx_show == null) {
                    $.cookie("sphinx_show", 1, { expires : 1 });
                }
                else
                {
                    return;
                }
            }
            $modal = "";
            if(settings.stick === 'on')
            {
                $modal += "<script>var $window = jQuery(window),$stickyEl = jQuery('#note'),elTop = $stickyEl.offset().top;$window.scroll(function() {$stickyEl.toggleClass('sticky', $window.scrollTop() > elTop);});</script>";
            }
            $modal += '<script>function clickClose(){note = document.getElementById("note");note.style.display = "none";}</script>'
            $modal += '<div name="note" id="note" style="color: '+settings.text+';background: '+settings.bkgrnd+'">' + settings.msg.content + ' <a id="close" style="color: '+settings.links+'" onclick="clickClose()">' + settings.msg.title + '</a></div>';
            $body.append($modal);   
        }
	});
})(jQuery);