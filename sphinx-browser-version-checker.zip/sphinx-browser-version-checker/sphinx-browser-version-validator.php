<?php
/** 
Plugin Name: Sphinx Browser Version Checker
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin automatically detects the version of browser your site's visitor uses.
Author: CodeRevolution
Version: 1.1
Author URI: https://codecanyon.net/user/kisded
*/
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/sphinx/master/info.json", __FILE__, "sphinx-browser-version-checker");
add_action('admin_menu', 'sphinx_register_my_custom_menu_page');
function sphinx_register_my_custom_menu_page()
{
    add_menu_page('Sphinx Browser Version Checker', 'Sphinx Browser Version Checker', 'manage_options', 'sphinx_admin_settings', 'sphinx_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('sphinx_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'sphinx_admin_settings');
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'sphinx_add_settings_link');
function sphinx_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=sphinx_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}


$chrome_curr_ver = 54;
$firefox_curr_ver = 49;
$ie_curr_ver = 11;
$opera_curr_ver = 41;
$safari_curr_ver = 10;
$edge_curr_ver = 14;


function sphinx_debug_to_console( $data ) {

    if ( is_array( $data ) )
        $output = "<script>console.log( 'Debug Objects: " . implode( ',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";

    echo $output;
}
register_activation_hook(__FILE__, 'sphinx_activation_callback');
function sphinx_activation_callback()
{
    $sphinx_Main_Settings = array(
        'sphinx_enabled' => 'on',
        'sfinx_ver_chrome' => '32',
        'sfinx_ver_firefox' => '12',
        'sfinx_ver_ie' => '8',
        'sfinx_ver_opera' => '10',
        'sfinx_ver_safari' => '8',
        'sfinx_mobile_support' => 'YES',
        'sfinx_ver_edge' => 'ALL',
        'sfinx_mobile_title' => 'Not supported on mobile devices!',
        'sfinx_mobile_message' => 'Please load this page only on desktop computers!',
        'sfinx_mobile_panel_message' => 'Please load this page only on desktop computers!',
        'sfinx_message_title' => 'Your browser is not supported!',
        'sfinx_message' => 'Please download the latest browser and try again!',
        'sfinx_links' => 'on',
        'sfinx_warn' => 'on',
        'sfinx_click_close' => 'on',
        'sfinx_close_popup' => 'Continue to this website anyway',
        'sfinx_popup_once' => 'off',
        'sfinx_check_mobile' => 'on',
        'sfinx_style' => 'sfinx_popup',
        'sfinx_panel_message' => 'This site does not support your browser! Please update it!',
        'sfinx_panel_close_message' => 'Close',
        'sfinx_panel_sticks' => 'on',
        'sfinx_popup_background' => '#ffffff',
        'sfinx_panel_background' => '#aaaaaa',
        'sfinx_popup_text_col' => '#000000',
        'sfinx_panel_text_col' => '#000000',
        'sfinx_popup_links_col' => '#0000ff',
        'sfinx_panel_links_col' => '#0000ff',
        'sfinx_mobile_panel_close' => 'Close'
    );
    if (!get_option('sphinx_Main_Settings')) {
        add_option('sphinx_Main_Settings', $sphinx_Main_Settings);
    } else {
        delete_option('sphinx_Main_Settings');
        add_option('sphinx_Main_Settings', $sphinx_Main_Settings);
    }
}

register_activation_hook(__FILE__, 'sphinx_check_version');
function sphinx_check_version() {
    	global $wp_version;
        if (!current_user_can('activate_plugins')) {
			echo '<p>' .
 			sprintf(
 			    __('You are not allowed to activate plugins!', 'oe-sb'),
 			    $php_version_required
 			)
 			. '</p>';
            die;
		}
		$php_version_required = '5.3';
		$wp_version_required = '2.7';
		
		if(version_compare(PHP_VERSION, $php_version_required, '<')) {
 			deactivate_plugins(basename(__FILE__));
 			echo '<p>' .
 			sprintf(
 			    __('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'),
 			    $php_version_required
 			)
 			. '</p>';
            die;
		}
        
		if(version_compare($wp_version, $wp_version_required, '<')) {
 			deactivate_plugins(basename(__FILE__));
			echo '<p>' .
			sprintf(
			__( 'This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb' ),
			$wp_version_required
			)
			. '</p>';
			die;
		}
    }

function sphinx_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('admin_enqueue_scripts', 'sphinx_load_admin_things');

add_action('admin_init', 'sphinx_register_mysettings');
function sphinx_register_mysettings()
{
    register_setting('sphinx_option_group', 'sphinx_Main_Settings');
}

add_action('wp_footer', 'sphinx_popup_footer_content');
function sphinx_popup_footer_content()
{
    $sphinx_Main_Settings = get_option('sphinx_Main_Settings', false);
?><script type="text/javascript">
        var $sphinx_Main_Settings = JSON.parse('<?php
    echo json_encode($sphinx_Main_Settings);
?>');
        </script><?php
}

function sphinx_get_plugin_url() {
    	return plugins_url('', __FILE__);
}

add_shortcode("sphinx_browser_info", "sphinx_browser_info");

function sphinx_browser_info()
{
    $obj = new SphinxBrowserDetection();
    return $obj->sphinx_detect()->sphinx_getInfo();
}

function sphinx_get_file_url($url) {
	return sphinx_get_plugin_url() . '/' . $url;
}	
add_action( 'template_redirect', 'sphinx_check_browser_version' );
function sphinx_check_browser_version()
{
    $sphinx_Main_Settings = get_option('sphinx_Main_Settings', false);
    if($sphinx_Main_Settings['sphinx_enabled'] == 'on')
    {
        if($sphinx_Main_Settings['sfinx_style'] == 'sfinx_popup')
        {
            if(sphinx_is_mobile($_SERVER['HTTP_USER_AGENT']) == 'true')
            {
                if($sphinx_Main_Settings['sfinx_mobile_support'] == 'NO')
                {   
                    wp_register_style('sphinx_enque_style', sphinx_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
                    wp_enqueue_style('sphinx_enque_style');
                    wp_register_script('sphinx_enque_script', sphinx_get_file_url('res/notification.js'), array('jquery'));
                    wp_enqueue_script('sphinx_enque_script');
                    $settings = array(
                            'browser' => array(),
                            'msg' => array(
                                'title' => $sphinx_Main_Settings["sfinx_mobile_title"],
                                'content' => $sphinx_Main_Settings["sfinx_mobile_message"],
                            ),
                            'warn' => 'off',
                            'click_outside' => 'off',
                            'close_message' => 'off',
                            'use_cookies' => 'off',
                            'panel' => 'no',
                            'bkgrnd' => $sphinx_Main_Settings['sfinx_popup_background'],
                            'text' => $sphinx_Main_Settings['sfinx_popup_text_col'],
                            'links' => $sphinx_Main_Settings['sfinx_popup_links_col']
                    );
                    wp_localize_script('sphinx_enque_script', 'settings', $settings);
                    return;
                }
                if($sphinx_Main_Settings['sfinx_check_mobile'] != 'on')
                {
                    return;
                }
            }
            $browser = sphinx_get_browser_version($_SERVER['HTTP_USER_AGENT'], $sphinx_Main_Settings["sfinx_check_mobile"]);        
            if($browser['name']) {
                $sfinx_links = $sphinx_Main_Settings["sfinx_links"];
                if($sfinx_links == 'on')
                {
                    switch (strtolower($browser['name'])) {
                        case 'chrome':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if ($required_version != "NO")
                                {
                                    if($required_version == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$required_version.'+';
                                    }
                                    $dwnld = array(
                                    'chrome' => array(
                                        'name' => 'Google Chrome',
                                        'icon' => sphinx_get_file_url('images/chrome.png'),
                                        'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                        'version' => $vers
                                    ));
                                }
                                else
                                {
                                    $dwnld = array();
                                    $req_firefox = $sphinx_Main_Settings["sfinx_ver_firefox"];
                                    if($req_firefox != 'NO')
                                    {
                                        if($req_firefox == "ALL")
                                        {
                                            $vers = 'All versions';
                                        }
                                        else
                                        {
                                            $vers = 'version '.$req_firefox.'+';
                                        }
                                        $dwnld["firefox"] = array(
                                        'name' => 'Mozilla Firefox',
                                        'icon' => sphinx_get_file_url('images/firefox.png'),
                                        'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                        'version' => $vers
                                        );
                                    }
                                    $req_ie = $sphinx_Main_Settings["sfinx_ver_ie"];
                                    if($req_ie != 'NO')
                                    {
                                        if($req_ie == "ALL")
                                        {
                                            $vers = 'All versions';
                                        }
                                        else
                                        {
                                            $vers = 'version '.$req_ie.'+';
                                        }
                                        $dwnld["ie"] = array(
                                        'name' => 'Internet Explorer',
                                        'icon' => sphinx_get_file_url('images/ie.png'),
                                        'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                        'version' => $vers
                                        );
                                    }
                                    $req_opera = $sphinx_Main_Settings["sfinx_ver_opera"];
                                    if($req_opera != 'NO')
                                    {
                                        if($req_opera == "ALL")
                                        {
                                            $vers = 'All versions';
                                        }
                                        else
                                        {
                                            $vers = 'version '.$req_opera.'+';
                                        }
                                        $dwnld["opera"] = array(
                                        'name' => 'Opera',
                                        'icon' => sphinx_get_file_url('images/opera.png'),
                                        'url' => 'http://www.opera.com/',
                                        'version' => $vers
                                        );
                                    }
                                    $req_safari = $sphinx_Main_Settings["sfinx_ver_safari"];
                                    if($req_safari != 'NO')
                                    {
                                        if($req_safari == "ALL")
                                        {
                                            $vers = 'All versions';
                                        }
                                        else
                                        {
                                            $vers = 'version '.$req_safari.'+';
                                        }
                                        $dwnld["safari"] = array(
                                        'name' => 'Safari',
                                        'icon' => sphinx_get_file_url('images/safari.png'),
                                        'url' => 'https://www.apple.com/safari/',
                                        'version' => $vers
                                        );
                                    }
                                    $req_edge = $sphinx_Main_Settings["sfinx_ver_edge"];
                                    if($req_edge != 'NO')
                                    {
                                        if($req_edge == "ALL")
                                        {
                                            $vers = 'All versions';
                                        }
                                        else
                                        {
                                            $vers = 'version '.$req_edge.'+';
                                        }
                                        $dwnld["edge"] = array(
                                        'name' => 'Edge',
                                        'icon' => sphinx_get_file_url('images/edge.png'),
                                        'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                        'version' => $vers
                                        );
                                    }
                                }
                            break;
                        case 'firefox':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_firefox"];
                            if ($required_version != "NO")
                            {
                                if($required_version == "ALL")
                                {
                                    $vers = 'All versions';
                                }
                                else
                                {
                                    $vers = 'version '.$required_version.'+';
                                }
                                $dwnld = array(
                                'firefox' => array(
                                    'name' => 'Mozilla Firefox',
                                    'icon' => sphinx_get_file_url('images/firefox.png'),
                                    'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                    'version' => $vers
                                ));
                            }
                            else
                            {
                                $dwnld = array();
                                $req_chrome = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if($req_chrome != 'NO')
                                {
                                    if($req_chrome == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_chrome.'+';
                                    }
                                    $dwnld["chrome"] = array(
                                    'name' => 'Google Chrome',
                                    'icon' => sphinx_get_file_url('images/chrome.png'),
                                    'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                    'version' => $vers
                                    );
                                }
                                $req_ie = $sphinx_Main_Settings["sfinx_ver_ie"];
                                if($req_ie != 'NO')
                                {
                                    if($req_ie == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_ie.'+';
                                    }
                                    $dwnld["ie"] = array(
                                    'name' => 'Internet Explorer',
                                    'icon' => sphinx_get_file_url('images/ie.png'),
                                    'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                    'version' => $vers
                                    );
                                }
                                $req_opera = $sphinx_Main_Settings["sfinx_ver_opera"];
                                if($req_opera != 'NO')
                                {
                                    if($req_opera == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_opera.'+';
                                    }
                                    $dwnld["opera"] = array(
                                    'name' => 'Opera',
                                    'icon' => sphinx_get_file_url('images/opera.png'),
                                    'url' => 'http://www.opera.com/',
                                    'version' => $vers
                                    );
                                }
                                $req_safari = $sphinx_Main_Settings["sfinx_ver_safari"];
                                if($req_safari != 'NO')
                                {
                                    if($req_safari == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_safari.'+';
                                    }
                                    $dwnld["safari"] = array(
                                    'name' => 'Safari',
                                    'icon' => sphinx_get_file_url('images/safari.png'),
                                    'url' => 'https://www.apple.com/safari/',
                                    'version' => $vers
                                    );
                                }
                                $req_edge = $sphinx_Main_Settings["sfinx_ver_edge"];
                                if($req_edge != 'NO')
                                {
                                    if($req_edge == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_edge.'+';
                                    }
                                    $dwnld["edge"] = array(
                                    'name' => 'Edge',
                                    'icon' => sphinx_get_file_url('images/edge.png'),
                                    'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                    'version' => $vers
                                    );
                                }
                            }
                            break;
                        case 'ie':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_ie"];
                            if ($required_version != "NO")
                            {
                                if($required_version == "ALL")
                                {
                                    $vers = 'All versions';
                                }
                                else
                                {
                                    $vers = 'version '.$required_version.'+';
                                }
                                $dwnld = array(
                                'ie' => array(
                                    'name' => 'Internet Explorer',
                                    'icon' => sphinx_get_file_url('images/ie.png'),
                                    'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                    'version' => $vers
                                ));
                            }
                            else
                            {
                                $dwnld = array();
                                $req_chrome = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if($req_chrome != 'NO')
                                {
                                    if($req_chrome == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_chrome.'+';
                                    }
                                    $dwnld["chrome"] = array(
                                    'name' => 'Google Chrome',
                                    'icon' => sphinx_get_file_url('images/chrome.png'),
                                    'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                    'version' => $vers
                                    );
                                }
                                $req_firefox = $sphinx_Main_Settings["sfinx_ver_firefox"];
                                if($req_firefox != 'NO')
                                {
                                    if($req_firefox == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_firefox.'+';
                                    }
                                    $dwnld["firefox"] = array(
                                    'name' => 'Mozilla Firefox',
                                    'icon' => sphinx_get_file_url('images/firefox.png'),
                                    'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                    'version' => $vers
                                    );
                                }
                                $req_opera = $sphinx_Main_Settings["sfinx_ver_opera"];
                                if($req_opera != 'NO')
                                {
                                    if($req_opera == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_opera.'+';
                                    }
                                    $dwnld["opera"] = array(
                                    'name' => 'Opera',
                                    'icon' => sphinx_get_file_url('images/opera.png'),
                                    'url' => 'http://www.opera.com/',
                                    'version' => $vers
                                    );
                                }
                                $req_safari = $sphinx_Main_Settings["sfinx_ver_safari"];
                                if($req_safari != 'NO')
                                {
                                    if($req_safari == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_safari.'+';
                                    }
                                    $dwnld["safari"] = array(
                                    'name' => 'Safari',
                                    'icon' => sphinx_get_file_url('images/safari.png'),
                                    'url' => 'https://www.apple.com/safari/',
                                    'version' => $vers
                                    );
                                }
                                $req_edge = $sphinx_Main_Settings["sfinx_ver_edge"];
                                if($req_edge != 'NO')
                                {
                                    if($req_edge == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_edge.'+';
                                    }
                                    $dwnld["edge"] = array(
                                    'name' => 'Edge',
                                    'icon' => sphinx_get_file_url('images/edge.png'),
                                    'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                    'version' => 'version '.$req_edge
                                    );
                                }
                            }
                            break;
                        case 'opera':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_opera"];
                            if ($required_version != "NO")
                            {
                                if($required_version == "ALL")
                                {
                                    $vers = 'All versions';
                                }
                                else
                                {
                                    $vers = 'version '.$required_version.'+';
                                }
                                $dwnld = array(
                                'opera' => array(
                                    'name' => 'Opera',
                                    'icon' => sphinx_get_file_url('images/opera.png'),
                                    'url' => 'http://www.opera.com/',
                                    'version' => $vers
                                ));
                            }
                            else
                            {
                                $dwnld = array();
                                $req_chrome = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if($req_chrome != 'NO')
                                {
                                    if($req_chrome == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_chrome.'+';
                                    }
                                    $dwnld["chrome"] = array(
                                    'name' => 'Google Chrome',
                                    'icon' => sphinx_get_file_url('images/chrome.png'),
                                    'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                    'version' => $vers
                                    );
                                }
                                $req_firefox = $sphinx_Main_Settings["sfinx_ver_firefox"];
                                if($req_firefox != 'NO')
                                {
                                    if($req_firefox == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_firefox.'+';
                                    }
                                    $dwnld["firefox"] = array(
                                    'name' => 'Mozilla Firefox',
                                    'icon' => sphinx_get_file_url('images/firefox.png'),
                                    'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                    'version' => $vers
                                    );
                                }
                                $req_ie = $sphinx_Main_Settings["sfinx_ver_ie"];
                                if($req_ie != 'NO')
                                {
                                    if($req_ie == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_ie.'+';
                                    }
                                    $dwnld["ie"] = array(
                                    'name' => 'Internet Explorer',
                                    'icon' => sphinx_get_file_url('images/ie.png'),
                                    'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                    'version' => $vers
                                    );
                                }
                                $req_safari = $sphinx_Main_Settings["sfinx_ver_safari"];
                                if($req_safari != 'NO')
                                {
                                    if($req_safari == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_safari.'+';
                                    }
                                    $dwnld["safari"] = array(
                                    'name' => 'Safari',
                                    'icon' => sphinx_get_file_url('images/safari.png'),
                                    'url' => 'https://www.apple.com/safari/',
                                    'version' => $vers
                                    );
                                }
                                $req_edge = $sphinx_Main_Settings["sfinx_ver_edge"];
                                if($req_edge != 'NO')
                                {
                                    if($req_edge == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_edge.'+';
                                    }
                                    $dwnld["edge"] = array(
                                    'name' => 'Edge',
                                    'icon' => sphinx_get_file_url('images/edge.png'),
                                    'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                    'version' => $vers
                                    );
                                }
                            }
                            break;
                        case 'safari':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_safari"];
                            if ($required_version != "NO")
                            {
                                if($required_version == "ALL")
                                {
                                    $vers = 'All versions';
                                }
                                else
                                {
                                    $vers = 'version '.$required_version.'+';
                                }
                                $dwnld = array(
                                'safari' => array(
                                    'name' => 'Safari',
                                    'icon' => sphinx_get_file_url('images/safari.png'),
                                    'url' => 'https://www.apple.com/safari/',
                                    'version' => $vers
                                ));
                            }
                            else
                            {
                                $dwnld = array();
                                $req_chrome = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if($req_chrome != 'NO')
                                {
                                    if($req_chrome == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_chrome.'+';
                                    }
                                    $dwnld["chrome"] = array(
                                    'name' => 'Google Chrome',
                                    'icon' => sphinx_get_file_url('images/chrome.png'),
                                    'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                    'version' => $vers
                                    );
                                }
                                $req_firefox = $sphinx_Main_Settings["sfinx_ver_firefox"];
                                if($req_firefox != 'NO')
                                {
                                    if($req_firefox == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_firefox.'+';
                                    }
                                    $dwnld["firefox"] = array(
                                    'name' => 'Mozilla Firefox',
                                    'icon' => sphinx_get_file_url('images/firefox.png'),
                                    'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                    'version' => $vers
                                    );
                                }
                                $req_ie = $sphinx_Main_Settings["sfinx_ver_ie"];
                                if($req_ie != 'NO')
                                {
                                    if($req_ie == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_ie.'+';
                                    }
                                    $dwnld["ie"] = array(
                                    'name' => 'Internet Explorer',
                                    'icon' => sphinx_get_file_url('images/ie.png'),
                                    'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                    'version' => $vers
                                    );
                                }
                                $req_opera = $sphinx_Main_Settings["sfinx_ver_opera"];
                                if($req_opera != 'NO')
                                {
                                    if($req_opera == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_opera.'+';
                                    }
                                    $dwnld["opera"] = array(
                                    'name' => 'Opera',
                                    'icon' => sphinx_get_file_url('images/opera.png'),
                                    'url' => 'http://www.opera.com/',
                                    'version' => $vers
                                    );
                                }
                                $req_edge = $sphinx_Main_Settings["sfinx_ver_edge"];
                                if($req_edge != 'NO')
                                {
                                    if($req_edge == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_edge.'+';
                                    }
                                    $dwnld["edge"] = array(
                                    'name' => 'Edge',
                                    'icon' => sphinx_get_file_url('images/edge.png'),
                                    'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                    'version' => $vers
                                    );
                                }
                            }
                            break;
                        case 'edge':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_edge"];
                            if ($required_version != "NO")
                            {
                                if($required_version == "ALL")
                                {
                                    $vers = 'All versions';
                                }
                                else
                                {
                                    $vers = 'version '.$required_version.'+';
                                }
                                $dwnld = array(
                                'opera' => array(
                                    'name' => 'Edge',
                                    'icon' => sphinx_get_file_url('images/edge.png'),
                                    'url' => 'https://www.microsoft.com/en-us/windows/microsoft-edge/microsoft-edge',
                                    'version' => $vers
                                ));
                            }
                            else
                            {
                                $dwnld = array();
                                $req_chrome = $sphinx_Main_Settings["sfinx_ver_chrome"];
                                if($req_chrome != 'NO')
                                {
                                    if($req_chrome == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_chrome.'+';
                                    }
                                    $dwnld["chrome"] = array(
                                    'name' => 'Google Chrome',
                                    'icon' => sphinx_get_file_url('images/chrome.png'),
                                    'url' => 'https://www.google.com/chrome/browser/desktop/index.html',
                                    'version' => $vers
                                    );
                                }
                                $req_firefox = $sphinx_Main_Settings["sfinx_ver_firefox"];
                                if($req_firefox != 'NO')
                                {
                                    if($req_firefox == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_firefox.'+';
                                    }
                                    $dwnld["firefox"] = array(
                                    'name' => 'Mozilla Firefox',
                                    'icon' => sphinx_get_file_url('images/firefox.png'),
                                    'url' => 'https://www.mozilla.org/en-US/firefox/new/',
                                    'version' => $vers
                                    );
                                }
                                $req_ie = $sphinx_Main_Settings["sfinx_ver_ie"];
                                if($req_ie != 'NO')
                                {
                                    if($req_ie == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_ie.'+';
                                    }
                                    $dwnld["ie"] = array(
                                    'name' => 'Internet Explorer',
                                    'icon' => sphinx_get_file_url('images/ie.png'),
                                    'url' => 'http://windows.microsoft.com/en-us/internet-explorer/download-ie',
                                    'version' => $vers
                                    );
                                }
                                $req_opera = $sphinx_Main_Settings["sfinx_ver_opera"];
                                if($req_opera != 'NO')
                                {
                                    if($req_opera == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_opera.'+';
                                    }
                                    $dwnld["opera"] = array(
                                    'name' => 'Opera',
                                    'icon' => sphinx_get_file_url('images/opera.png'),
                                    'url' => 'http://www.opera.com/',
                                    'version' => $vers
                                    );
                                }
                                $req_safari = $sphinx_Main_Settings["sfinx_ver_safari"];
                                if($req_safari != 'NO')
                                {
                                    if($req_safari == "ALL")
                                    {
                                        $vers = 'All versions';
                                    }
                                    else
                                    {
                                        $vers = 'version '.$req_safari.'+';
                                    }
                                    $dwnld["safari"] = array(
                                    'name' => 'Safari',
                                    'icon' => sphinx_get_file_url('images/safari.png'),
                                    'url' => 'https://www.apple.com/safari/',
                                    'version' => $vers
                                    );
                                }
                            }
                            break;
                        default:
                            $required_version = "";
                            $dwnld = array();
                    }
                }
                else
                {
                    switch (strtolower($browser['name'])) {
                        case 'chrome':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_chrome"];
                            break;
                        case 'firefox':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_firefox"];
                            break;
                        case 'ie':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_ie"];
                            break;
                        case 'opera':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_opera"];
                            break;
                        case 'safari':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_safari"];
                            break;
                        case 'edge':
                            $required_version = $sphinx_Main_Settings["sfinx_ver_edge"];
                            break;
                        default:
                            $required_version = "";
                    }
                    $dwnld = array();
                }
                
                if($required_version != "" && $required_version != 'ALL' && ($required_version == 'NO' || version_compare($required_version, $browser['version'], ">"))){
                    wp_register_style('sphinx_enque_style', sphinx_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
                    wp_enqueue_style('sphinx_enque_style');
                    wp_register_script('sphinx_enque_script', sphinx_get_file_url('res/notification.js'), array('jquery'));
                    wp_enqueue_script('sphinx_enque_script');
                    $settings = array(
                        'browser' => $dwnld,
                        'msg' => array(
                            'title' => $sphinx_Main_Settings["sfinx_message_title"],
                            'content' => $sphinx_Main_Settings["sfinx_message"],
                        ),
                        'warn' => $sphinx_Main_Settings['sfinx_warn'],
                        'click_outside' => $sphinx_Main_Settings['sfinx_click_close'],
                        'close_message' => $sphinx_Main_Settings['sfinx_close_popup'],
                        'use_cookies' => $sphinx_Main_Settings['sfinx_popup_once'],
                        'panel' => 'no',
                        'bkgrnd' => $sphinx_Main_Settings['sfinx_popup_background'],
                        'text' => $sphinx_Main_Settings['sfinx_popup_text_col'],
                        'links' => $sphinx_Main_Settings['sfinx_popup_links_col']
                    );
                    wp_localize_script('sphinx_enque_script', 'settings', $settings);
                }
            }
        }
        else
        {
            if(sphinx_is_mobile($_SERVER['HTTP_USER_AGENT']) == 'true')
            {
                if($sphinx_Main_Settings['sfinx_mobile_support'] == 'NO')
                {
                    wp_register_style('sphinx_enque_style', sphinx_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
                    wp_enqueue_style('sphinx_enque_style');
                    wp_register_script('sphinx_enque_script', sphinx_get_file_url('res/notification.js'), array('jquery'));
                    wp_enqueue_script('sphinx_enque_script');
                    $settings = array(
                            'browser' => array(),
                            'msg' => array(
                                'title' => $sphinx_Main_Settings["sfinx_mobile_panel_close"],
                                'content' => $sphinx_Main_Settings["sfinx_mobile_panel_message"],
                            ),
                            'use_cookies' => $sphinx_Main_Settings['sfinx_popup_once'],
                            'panel' => 'yes',
                            'stick' => $sphinx_Main_Settings['sfinx_panel_sticks'],
                            'bkgrnd' => $sphinx_Main_Settings['sfinx_panel_background'],
                            'text' => $sphinx_Main_Settings['sfinx_panel_text_col'],
                            'links' => $sphinx_Main_Settings['sfinx_panel_links_col']
                    );
                    wp_localize_script('sphinx_enque_script', 'settings', $settings);
                    return;
                }
                if($sphinx_Main_Settings['sfinx_check_mobile'] != 'on')
                {
                    return;
                }
            }
            $browser = sphinx_get_browser_version($_SERVER['HTTP_USER_AGENT'], $sphinx_Main_Settings["sfinx_check_mobile"]);        
            if($browser['name']) {
                switch (strtolower($browser['name'])) 
                {
                    case 'chrome':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_chrome"];
                        break;
                    case 'firefox':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_firefox"];
                        break;
                    case 'ie':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_ie"];
                        break;
                    case 'opera':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_opera"];
                        break;
                    case 'safari':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_safari"];
                        break;
                    case 'edge':
                        $required_version = $sphinx_Main_Settings["sfinx_ver_edge"];
                        break;
                    default:
                        $required_version = "";
                }
                $dwnld = array();
            }
            if($required_version != "" && $required_version != 'ALL' && ($required_version == 'NO' || version_compare($required_version, $browser['version'], ">")))
            {
                wp_register_style('sphinx_enque_style', sphinx_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
                wp_enqueue_style('sphinx_enque_style');
                wp_register_script('sphinx_enque_script', sphinx_get_file_url('res/notification.js'), array('jquery'));
                wp_enqueue_script('sphinx_enque_script');
                $settings = array(
                    'browser' => $dwnld,
                    'msg' => array(
                        'title' => $sphinx_Main_Settings["sfinx_panel_close_message"],
                        'content' => $sphinx_Main_Settings["sfinx_panel_message"],
                    ),
                    'use_cookies' => $sphinx_Main_Settings['sfinx_popup_once'],
                    'panel' => 'yes',
                    'stick' => $sphinx_Main_Settings['sfinx_panel_sticks'],
                    'bkgrnd' => $sphinx_Main_Settings['sfinx_panel_background'],
                    'text' => $sphinx_Main_Settings['sfinx_panel_text_col'],
                    'links' => $sphinx_Main_Settings['sfinx_panel_links_col']
                );
                wp_localize_script('sphinx_enque_script', 'settings', $settings);
            }
        }
    }
}

add_action('admin_enqueue_scripts', 'sphinx_admin_load_files');
function sphinx_admin_load_files()
{
    global $chrome_curr_ver, $firefox_curr_ver, $ie_curr_ver, $opera_curr_ver, $safari_curr_ver, $edge_curr_ver;
    
    wp_register_style('sphinx-browser-style', plugins_url('styles/sphinx-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('sphinx-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('sphinx-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('sphinx-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('sphinx-settings-app', plugins_url('res/sphinx-angular.js', __FILE__), array(), '1.0.0', true);//this
    $settings = array(
        'chrome' => $chrome_curr_ver,
        'firefox' => $firefox_curr_ver,
        'ie' => $ie_curr_ver,
        'opera' => $opera_curr_ver,
        'safari' => $safari_curr_ver,
        'edge' => $edge_curr_ver
    );
    wp_localize_script('sphinx-settings-app', 'settings', $settings);
}

require(dirname(__FILE__) . "/res/sphinx-main.php");
require(dirname(__FILE__) . "/res/sphinx-browser-detector.php");
?>